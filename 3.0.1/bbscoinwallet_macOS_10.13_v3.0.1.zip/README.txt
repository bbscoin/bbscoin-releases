Please install qt5 before running the wallet/
You can install from homebrew:

brew install qt5