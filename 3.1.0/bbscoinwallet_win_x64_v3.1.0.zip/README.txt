Following dependencies need to be installed before running the wallet:

Windows binary require VC2017 runtime.
Download from https://aka.ms/vs/15/release/vc_redist.x64.exe

Universal C Runtime
https://support.microsoft.com/en-us/help/2999226/update-for-universal-c-runtime-in-windows

Note: if your windows username is not in English. Please create a shortcut and add --data-dir=YOUR_OWN_DATA_FOLDER_PATH to the target.

For example:
https://camo.githubusercontent.com/e4fbd6cb07dbbfeb8909fbf9a32ed34f0ab80190/68747470733a2f2f692e696d6775722e636f6d2f6d69734b71694f2e706e67
