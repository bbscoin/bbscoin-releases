# BBSCoin Plugin for myBB

You should install the newPoints first, then upload the files to mybb.

# Install the walletd service

You need install and run the walletd service on your server

https://github.com/bbscoin/bbscoin/wiki/How-to-run-wallet-service-for-web-site%3F
