# BBSCoin Plugin for SMF

You should install the SMFShop first, then upload the files to SMF Packages.

# Install the walletd service

You need install and run the walletd service on your server

https://github.com/bbscoin/bbscoin/wiki/How-to-run-wallet-service-for-web-site%3F
